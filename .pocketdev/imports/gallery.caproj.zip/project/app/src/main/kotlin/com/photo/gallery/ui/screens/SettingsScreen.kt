package com.photo.gallery.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.photo.gallery.data.local.SecuritySettings
import com.photo.gallery.ui.theme.BentoAccent
import com.photo.gallery.ui.theme.BentoAccentContainer
import com.photo.gallery.ui.theme.BentoAccentSubtle
import com.photo.gallery.ui.theme.BentoAmber
import com.photo.gallery.ui.theme.BentoBg
import com.photo.gallery.ui.theme.BentoBorder
import com.photo.gallery.ui.theme.BentoGreen
import com.photo.gallery.ui.theme.BentoSurface
import com.photo.gallery.ui.theme.BentoSurfaceCard
import com.photo.gallery.ui.theme.BentoSurfaceElevated
import com.photo.gallery.ui.theme.BentoTextPrimary
import com.photo.gallery.ui.theme.BentoTextSecondary
import com.photo.gallery.ui.theme.BentoTextTertiary

/**
 * Settings Screen styled with Bento Grid aesthetic:
 * rounded-[28px] containers, #252429 backgrounds, #44474E borders,
 * lavender high-contrast switches and badges.
 */
@Composable
fun SettingsScreen(
    securitySettings: SecuritySettings,
    isBiometricAvailable: Boolean,
    onSetPinClick: () -> Unit,
    onToggleBiometrics: (Boolean) -> Unit,
    onToggleDeletionLock: (Boolean) -> Unit,
    onRequestChangeVaultCode: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BentoBg)
            .verticalScroll(rememberScrollState())
            .testTag("settings_screen")
    ) {
        // Header Subtitle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(BentoAccentSubtle),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = BentoAccent,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "Security & Privacy",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BentoTextPrimary
                )
                Text(
                    text = "VaultCore Protection & Deletion Lock",
                    style = MaterialTheme.typography.bodySmall,
                    color = BentoTextSecondary
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Master PIN Section
            BentoSettingsCard(title = "Authentication Credentials") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Password,
                            contentDescription = null,
                            tint = BentoAccent,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Master Security PIN",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = BentoTextPrimary
                            )
                            Text(
                                text = if (securitySettings.hasPinSet) "Configured (Salted SHA-256)" else "Not Configured",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (securitySettings.hasPinSet) BentoGreen else BentoAmber
                            )
                        }
                    }

                    Button(
                        onClick = onSetPinClick,
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BentoAccent,
                            contentColor = BentoAccentContainer
                        ),
                        modifier = Modifier.testTag("change_pin_button")
                    ) {
                        Text(
                            text = if (securitySettings.hasPinSet) "Change" else "Set PIN",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }

                // Biometrics Toggle
                if (isBiometricAvailable) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = null,
                                tint = BentoAccent,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Biometric Authentication",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = BentoTextPrimary
                                )
                                Text(
                                    text = "Unlock with fingerprint or face",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BentoTextSecondary
                                )
                            }
                        }

                        Switch(
                            checked = securitySettings.biometricsEnabled,
                            onCheckedChange = onToggleBiometrics,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = BentoAccentContainer,
                                checkedTrackColor = BentoAccent,
                                uncheckedThumbColor = BentoTextTertiary,
                                uncheckedTrackColor = BentoSurfaceElevated
                            ),
                            modifier = Modifier.testTag("biometric_switch")
                        )
                    }
                }

                // Vault Access Code - replaces the removed bottom-nav "VAULT" tab.
                // Typing this phrase into the search bar opens the hidden vault.
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = BentoAccent,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Vault Access Code",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = BentoTextPrimary
                            )
                            Text(
                                text = "Type your secret phrase in search to open the vault",
                                style = MaterialTheme.typography.bodySmall,
                                color = BentoTextSecondary
                            )
                        }
                    }

                    Button(
                        onClick = onRequestChangeVaultCode,
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BentoAccent,
                            contentColor = BentoAccentContainer
                        ),
                        modifier = Modifier.testTag("change_vault_code_button")
                    ) {
                        Text(text = "Change", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Flagship Feature: Deletion Lock
            BentoSettingsCard(title = "Flagship Protection") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = BentoAccent,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Deletion Lock Engine",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = BentoTextPrimary
                            )
                            Text(
                                text = "Require PIN or biometrics before any locked item can be deleted",
                                style = MaterialTheme.typography.bodySmall,
                                color = BentoTextSecondary
                            )
                        }
                    }

                    Switch(
                        checked = securitySettings.deletionLockEnabled,
                        onCheckedChange = onToggleDeletionLock,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BentoAccentContainer,
                            checkedTrackColor = BentoAccent,
                            uncheckedThumbColor = BentoTextTertiary,
                            uncheckedTrackColor = BentoSurfaceElevated
                        ),
                        modifier = Modifier.testTag("deletion_lock_switch")
                    )
                }
            }

            // Architecture & Privacy Details Card
            BentoSettingsCard(title = "VaultCore Architecture") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureDetailRow(
                        icon = Icons.Default.Lock,
                        title = "Local Room Persistence",
                        desc = "Locks are mapped via absolute file paths & SHA hashes to survive media re-indexing."
                    )
                    FeatureDetailRow(
                        icon = Icons.Default.Security,
                        title = ".nomedia Isolated Vault",
                        desc = "Private files reside in internal app storage invisible to external scanners."
                    )
                    FeatureDetailRow(
                        icon = Icons.Default.Shield,
                        title = "Background Vault Listener",
                        desc = "Real-time FileObserver monitors directory changes, auto-restoring .nomedia and syncing manually added or moved files."
                    )
                    FeatureDetailRow(
                        icon = Icons.Default.Info,
                        title = "Zero Cloud Leakage",
                        desc = "100% offline, privacy-first design. No analytics or tracking."
                    )
                }
            }
        }
    }
}

@Composable
private fun BentoSettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .border(1.dp, BentoBorder, RoundedCornerShape(28.dp)),
        colors = CardDefaults.cardColors(containerColor = BentoSurfaceCard)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = BentoAccent,
                letterSpacing = 1.2.sp,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
private fun FeatureDetailRow(
    icon: ImageVector,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = BentoAccent,
            modifier = Modifier
                .padding(top = 2.dp)
                .size(16.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = BentoTextPrimary
            )
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall,
                color = BentoTextSecondary,
                fontSize = 12.sp
            )
        }
    }
}

/**
 * Lets the user change the search-bar phrase that opens the hidden vault (default
 * "\vault"). Blank input is rejected (falls back to the previous code) so the user
 * can never accidentally lock themselves out of the vault entry point entirely.
 */
@Composable
fun VaultCodeEditDialog(
    currentCode: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(currentCode) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = BentoSurface,
        title = {
            Text(text = "Change Vault Access Code", color = BentoTextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text(
                    text = "Whatever you type here, typing it into the search bar will open the vault.",
                    color = BentoTextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = BentoTextPrimary,
                        unfocusedTextColor = BentoTextPrimary,
                        focusedIndicatorColor = BentoAccent,
                        unfocusedIndicatorColor = BentoTextTertiary,
                        cursorColor = BentoAccent
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("vault_code_input")
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val trimmed = text.trim()
                    if (trimmed.isNotEmpty()) onConfirm(trimmed) else onDismiss()
                },
                modifier = Modifier.testTag("vault_code_save_button")
            ) {
                Text(text = "Save", color = BentoAccent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Cancel", color = BentoTextSecondary)
            }
        }
    )
}
